<?php 
    session_start();
    if (!isset($_SESSION['login']))
        header("Location: login.html");
?>
<html>
        <head>
            <title>Chen phong ban</title>
            <meta charset="utf-8">
        </head>
        <body>
            <h3>Chen phong ban</h3>
            <form action="../controller/C_phongban.php" method="GET" name="form">
                <div class="container">
                    <input type = "hidden" value = "chen_phong_ban" name="request">

                    <label for="Id"><b>IDPB: </b></label>
                    <input type="text" placeholder="Nhap idpb" name="Id" required>

                    <label for="Ten"><b>Ten phong ban: </b></label>
                    <input type="text" placeholder="Nhap ten phong ban" name="Ten" required>

                    <label for="MoTa"><b>Mo ta: </b></label>
                    <input type="text" placeholder="Nhap mo ta" name="MoTa" required>
                
                    <button class = "btn ok">OK</button>
                    <button type="submit" class = "btn reset">Reset</button>
                </div> 
            </form>
            <form action="../Index.html" method="GET">
                <button class = "btn goback" style="background : gray"> Home </button>
            </form>
        </body>
    </html>
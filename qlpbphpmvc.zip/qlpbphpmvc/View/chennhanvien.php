<?php
    session_start();
    if (!isset($_SESSION['login'])){
        header("Location: login.html");
        exit();
    }
        
?>
<html>
        <head>
            <title>Chen nhan vien</title>
            <meta charset="utf-8">
        </head>
        <body>
            <h3>Chen nhan vien</h3>
            <form action="../controller/C_NhanVien.php" method="GET" name="form">
                <div class="container">
                <input type = "hidden" value = "chen_nhan_vien" name="request">

                <label for="Id"><b>ID:</b></label>
                <input type="text" name="Id" placeholder="Nhap id nhan vien" required>
            
                <label for="HoTen"><b>Ho ten:</b></label>
                <input type="text" placeholder="Nhap ho ten"  name="HoTen" required>

                <label for="Idpb"><b>IDPB: </b></label>
                <input type="text" placeholder="Nhap idpb"name="Idpb" required>

                <label for="DiaChi"><b>Dia chi: </b></label>
                <input type="text" placeholder="Nhap dia chi"name="DiaChi" required>
            
                <button class = "btn ok">OK</button>
                <button type="submit" class = "btn reset">Reset</button>
                </div>
            </form>
            <form action="../Index.html" method="GET">
                <button class = "btn goback" style="background : gray"> Home </button>
            </form>
        </body>
    </html>
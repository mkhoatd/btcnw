<!DOCTYPE html>
<html>
    <head>
    </head>
    <body>

    <h1>Thong tin phong ban</h1>

    <table id="main">
        <tr>
            <th>Id</th>
            <th>Ten phong ban</th>
            <th>Mo ta</th>
            <th>Cap nhat</th>
        </tr>
        <?php
            foreach($result as $value){
                echo "<tr>";
                echo "<td>".$value -> Id."</td>";
                echo "<td>".$value -> Ten."</td>"; 
                echo "<td>".$value -> MoTa."</td>";
                echo "<td >"."<a href = '../controller/C_PhongBan.php?Id=".$value -> Id."&request=form_cap_nhat'>xxx</a>"."</td>";
                echo "</tr>";
            }
        ?>
    </table>
    <form action="../Index.html method="GET">
        <button class = "btn goback" style="background : gray"> Home </button>
    </form>
    </body>
</html>
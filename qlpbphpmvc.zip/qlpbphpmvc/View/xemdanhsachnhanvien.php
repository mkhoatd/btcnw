<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<h1>Danh sach nhan vien</h1>

<table id="main">
    <tr>
        <th>Id</th>
        <th>Ho ten</th>
        <th>Idpb</th>
        <th>Dia chi</th>
        <th>Xoa</th>
    </tr>
    <?php
    foreach ($result as $value){
        echo "<tr>";
        echo "<td>".$value->Id."</td>";
        echo "<td>$value->HoTen</td>";
        echo "<td>$value->Idpb</td>";
        echo "<td>$value->DiaChi</td>";
        echo "<td><a href='../Controller/C_NhanVien.php?request=xoa_nhan_vien&Id='$value->Id>Xoa</a></td>";
        echo "<tr>";
    }
    ?>
</table>
<br/>
<a href="../Index.html">Back to Homepage</a>
</body>
</html>

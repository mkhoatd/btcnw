<html>
        <head>
            <title>Form cap nhat phong ban</title>
            <meta charset="utf-8">
        </head>
        <body>
            <h3>Cap nhat phong ban</h3>
            <form action="../Controller/C_PhongBan.php" method="GET" name="form">
                <div class="container">
                    <input type="hidden" name="request" value="cap_nhat_phong_ban" />
                    <label for="Id"><b>ID Phong Ban</b></label>
                    <input type="text" name="Id" value = '<?php echo $result -> Id ?>' readonly>
                
                    <label for="Ten"><b>Ten phong ban</b></label>
                    <input type="text" placeholder="Nhap ten phong ban" value = '<?php echo $result -> Ten ?>'  name="Ten">

                    <label for="MoTa"><b>Mo ta phong ban</b></label>
                    <input type="text" placeholder="Nhap mo ta phong ban" value = '<?php echo $result[0] -> MoTa ?>' name="MoTa">
                
                    <button class = "btn ok">OK</button>
                    <button type="submit" class = "btn reset">Reset</button>
                </div>
            </form>
            <form action="../Index.html" method="GET">
                <button class = "btn goback" style="background : gray"> Home </button>
            </form>
        </body>
    </html>
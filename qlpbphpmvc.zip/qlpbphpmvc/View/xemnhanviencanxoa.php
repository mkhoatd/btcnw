<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="../views/styles/form-style.css" />
        <link rel="stylesheet" href="../views/styles/table-style.css" /> 
    </head>
    <body>

    <h1>Xoa nhan vien</h1>

    <form action="../Controller/C_NhanVien.php" method="GET">
        <input type="hidden" name="request" value="xoa_nhan_vien"/>
        <table id="main">
            <tr>
                <th>Id</th>
                <th>Ho ten</th>
                <th>Idpb</th>
                <th>Dia chi</th>
                <th>Xoa nhan vien</th>
            </tr>
            <?php
                foreach($result as $value){
                    echo "<tr>";
                    echo "<td>".$value -> Id."</td>";
                    echo "<td>".$value -> HoTen."</td>"; 
                    echo "<td>".$value -> Idpb."</td>";
                    echo "<td>".$value -> DiaChi."</td>";
                    echo "<td>".
                     "<a href='../Controller/C_NhanVien?request=xoa_nhan_vien&Id=$value->Id'>Xoa</a>"."</td>";
                    echo "</tr>";
                }
            ?>
        </table>
        <button class = "btn ok">OK</button>
    </form>
    <form action="../controller/C_NhanVien.php" method="GET">
        <input type="hidden" name="request" value="xoa_toan_bo_nhan_vien"/>
        <button class = "btn remove" style="background-color: red;">XOA HET NHAN VIEN</button>
    </form>

    <form action="../Index.html" method="GET">
        <button class = "btn goback" style="background : gray"> Home </button>
    </form>
    </body>
</html>
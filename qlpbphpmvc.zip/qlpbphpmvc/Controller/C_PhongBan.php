<?php
require_once ('../Model/M_PhongBan.php');
class C_PhongBan
{
    public function invoke(){
        $request=$_GET['request'];
        switch ($request){
            case "xem_danh_sach_phong_ban":
                $result=M_PhongBan::getAllPhongBan();
                include_once ("../View/xemdanhsachphongban.php");
                break;
            case "xem_nhan_vien_phong_ban":
                $Idpb=$_GET['Idpb'];
                $result=M_NhanVien::getNhanVienByIdpb($Idpb);
                include_once ("../View/xemdanhsachnhanvienphongban.php");
                break;
            case "chen_phong_ban":
                $Id=$_GET['Id'];
                $Ten=$_GET['Ten'];
                $MoTa=$_GET['MoTa'];
                M_PhongBan::insertPhongBan($Id,$Ten,$MoTa);
                header("Location: C_PhongBan.php?request=xem_danh_sach_phong_ban");
            case "thong_tin_cap_nhat":
                $result = M_PhongBan::getAllPhongBan();
                include_once("../views/capnhat.php");
                break;
            case "form_cap_nhat":
                $result=M_PhongBan::getPhongBanById($_GET['Id']);
                include_once("../views/form_cap_nhat.php");
                break;
            case "cap_nhat_phong_ban":
                $Id=$_GET['Id'];
                $Ten=$_GET['Ten'];
                $MoTa=$_GET['MoTa'];
                M_PhongBan::updatePhongBan($Id,$Ten,$MoTa);
                header("Location: C_PhongBan.php?request=xem_danh_sach_phong_ban");
        }
    }
}
$c_phongban=new C_PhongBan();
$c_phongban->invoke();
<?php
require_once ('../Model/M_NhanVien.php');
class C_NhanVien
{
    public function invoke(){
        $request=$_GET['request'];
        switch ($request){
            case "xem_danh_sach_nhan_vien":
                $result=M_NhanVien::getAllNhanVien();
                include_once ("../View/xemdanhsachnhanvien.php");
                break;
            case "xem_nhan_vien_phong_ban":
                $Idpb=$_GET['Idpb'];
                $result=M_NhanVien::getNhanVienByIdpb($Idpb);
                include_once ("../View/xemdanhsachnhanvienphongban.php");
                break;
            case "tim_kiem_by_Id":
                $Id=$_GET['Id'];
                $result=M_NhanVien::getNhanVienById($Id);
                include_once ("../View/xemdanhsachnhanvien.php");
                break;
            case "tim_kiem_by_name":
                $HoTen=$_GET['HoTen'];
                $result=M_NhanVien::getNhanVienByName($HoTen);
                include_once ("../View/xemdanhsachnhanvien.php");
                break;
            case "chen_nhan_vien":
                $Id=$_GET['Id'];
                $HoTen=$_GET['HoTen'];
                $Idpb=$_GET['Idpb'];
                $DiaChi=$_GET['DiaChi'];
                $result=M_NhanVien::insertNhanVien($Id,$HoTen,$Idpb,$DiaChi);
                header("Location: C_NhanVien.php?request=xem_danh_sach_nhan_vien");
                break;
            case "xem_nv_can_xoa":
                $result = M_NhanVien::getAllNhanVien();
                include_once("../View/xemnhanviencanxoa.php");
                break;
            case "xoa_nhan_vien":
                $Id=$_GET['Id'];
                M_NhanVien::deleteNhanVienById($Id);
                header("Location: C_NhanVien.php?request=xem_danh_sach_nhan_vien");
                break;
            case "xoa_toan_bo_nhan_vien":
                M_NhanVien::deleteAllNhanVien();
                header("Location: C_NhanVien.php?request=xem_danh_sach_nhan_vien");
                break;
        }
    }
}
$c_nhanvien=new C_NhanVien();
$c_nhanvien->invoke();
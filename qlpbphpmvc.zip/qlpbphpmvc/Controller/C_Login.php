<?php
session_start();

class C_Login
{
    public function invoke(){
        $username=$_POST['username'];
        $password=$_POST['password'];
        $link=mysqli_connect("localhost","root","root") or die("Khong the ket noi CSDL");
        mysqli_select_db($link,"dulieu");
        $sql="select * from Admin where username='$username' and password='$password'";
        $result=mysqli_query($link, $sql);
        if($result->num_rows>0){
            $_SESSION['login']=1;
            header('Location: ../Index.html');
            exit();
        }
        else header("Location: ../View/login.html");
        $link->close();
        mysqli_free_result($result);
    }
}
$c_login=new C_Login();
$c_login->invoke();
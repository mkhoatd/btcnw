<?php

class E_NhanVien
{
    public $Id;
    public $HoTen;
    public $Idpb;
    public $DiaChi;
    public function __construct($Id, $HoTen, $Idpb, $DiaChi)
    {
        $this->Id=$Id;
        $this->HoTen=$HoTen;
        $this->DiaChi=$DiaChi;
        $this->Idpb=$Idpb;
    }
}
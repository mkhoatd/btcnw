<?php
include_once ('E_PhongBan.php');
include_once ('M_NhanVien.php');
class M_PhongBan
{
    public static function getAllPhongBan(){
        $connection=new mysqli('localhost','root','root','dulieu');
        if($connection->connect_error){
            die("Connection failed ".$connection->connect_error);
        }
        $sql="select * from phongban";
        $result=$connection->query($sql);
        $returnResult=array();
        while($value=$result->fetch_assoc()){
            $returnResult[$value['Id']]=new E_PhongBan($value['Id'],$value['Ten'],$value['Mo ta']);
        }
        $result->free();
        $connection->close();
        return $returnResult;
    }
    public static function getPhongBanById($Id){
        $connection=new mysqli('localhost','root','root','dulieu');
        if($connection->connect_error){
            die("Connection failed ".$connection->connect_error);
        }
        $sql="select * from phongban where Id=$Id";
        $result=$connection->query($sql);
        $row=$result->fetch_assoc();
        $phongban=new E_PhongBan($row['Idd'], $row['Ten'], $row['Mo ta']);
        $result->free();
        $connection->close();
        return $phongban;
    }
    public static function insertPhongBan($Id, $Ten, $MoTa){
        $connection=new mysqli('localhost','root','root','dulieu');
        if($connection->connect_error){
            die("Connection failed ".$connection->connect_error);
        }
        $preparedStatement=$connection->prepare('insert into phongban values(?, ?, ?)');
        $preparedStatement->bind_param("iss",$Id,$Ten,$MoTa);
        if($preparedStatement->execute()) header("Location: ../View/insertphongban");
    }
    public static function deletePhongBan($Id){
        $connection=new mysqli('localhost','root','root','dulieu');
        if($connection->connect_error){
            die("Connection failed ".$connection->connect_error);
        }
        $sql='delete from nhanvien where Idpb=$Id';
        $connection->query($sql);
        $sql='delete from phongban where Id=$Id';
        $connection->query($sql);
        $connection->close();
    }
    public static function updatePhongBan($Id,$Ten,$MoTa){
        $connection=new mysqli('localhost','root','root','dulieu');
        if($connection->connect_error){
            die("Connection failed ".$connection->connect_error);
        }
        $preparedStatement=$connection->prepare('update phongban set Ten=?, Mo ta=? where Id=?');
        $preparedStatement->bind_param("ssi",$Ten,$MoTa,$Id);
        $preparedStatement->execute();
    }
}
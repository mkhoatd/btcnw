<?php
include_once ('E_NhanVien.php');

class E_PhongBan
{
    public $Id;
    public $Ten;
    public $MoTa;

    public function __construct($Id, $Ten, $MoTa){
        $this->Id=$Id;
        $this->Ten=$Ten;
        $this->MoTa=$MoTa;
    }
}
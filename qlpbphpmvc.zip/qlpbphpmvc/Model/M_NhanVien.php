<?php
include_once ('E_NhanVien.php');

class M_NhanVien
{
    public static function getAllNhanVien(){
        $link=mysqli_connect("localhost","root","root") or die("Khong the ket noi CSDL");
        mysqli_select_db($link,"dulieu");
        $sql="select * from nhanvien";
//        $result=mysqli_query($link, $sql);
        $result=$link->query($sql);
        $returnValue=array();
        while($row=$result->fetch_assoc())
        {
            $returnValue[$row['Id']] = new E_NhanVien($row['Id'], $row['Ho ten'], $row['Idpb'], $row['Dia chi']);
        }
        $link->close();
        return $returnValue;
    }
    public static function getNhanVienById($Id){
        $connection=new mysqli('localhost','root','root','dulieu');
        if($connection->connect_error){
            die("Connection failed ".$connection->connect_error);
        }
        $sql="select * from nhanvien where Id like '%$Id%'";
        $result=$connection->query($sql);
        $returnValue=array();
        while($row=$result->fetch_assoc())
        {
            $returnValue[$row['Id']] = new E_NhanVien($row['Id'], $row['Ho ten'], $row['Idpb'], $row['Dia chi']);
        }
        return $returnValue;
    }
    public static function getNhanVienByIdpb($Idpb){
        $nhanViens=self::getAllNhanVien();
        $result=array();
        foreach ($nhanViens as $value){
            if($value->Idpb==$Idpb){
                $result[$value->Id]=$value;
            }
        }
    }
    public static function getNhanVienByName($HoTen){
        $connection=new mysqli('localhost','root','root','dulieu');
        if($connection->connect_error){
            die("Connection failed ".$connection->connect_error);
        }
        $sql="select * from nhanvien where `Ho ten` like '%$HoTen%'";
        $result=$connection->query($sql);
        $returnValue=array();
        while($row=$result->fetch_assoc())
        {
            $returnValue[$row['Id']] = new E_NhanVien($row['Id'], $row['Ho ten'], $row['Idpb'], $row['Dia chi']);
        }
        return $returnValue;
    }
    public static function deleteAllNhanVien(){
        $link=mysqli_connect("localhost","root","root","dulieu");
        if($link->connect_error){
            die("Connection failed. ".$link->connect_error);
        }
        $sql="delete from nhanvien";
        $link->query($sql);
        $link->close();
    }
    public static function deleteNhanVienById($Id){
        $connection=new mysqli('localhost','root','root','dulieu');
        if($connection->connect_error){
            die("Connection failed ".$connection->connect_error);
        }
        $preparedSql=$connection->prepare("delete from nhanvien where Id=?");
        $preparedSql->bind_param("i",$Id);
        $preparedSql->execute();
        $connection->close();
    }
    public static function insertNhanVien($Id, $HoTen, $Idpb, $DiaChi)
    {
        $connection=new mysqli('localhost','root','root','dulieu');
        if($connection->connect_error){
           die("Connection failed ".$connection->connect_error);
        }
        $preparedSql=$connection->prepare("insert into nhanvien values (?,?,?,?)");
        $preparedSql->bind_param("isis",$Id,$HoTen,$Idpb,$DiaChi);
        if($preparedSql->execute()){
           header('Location: ../View/chennhanvien.php');
        }
    }
    public static function updateNhanVien($HoTen, $Idpb, $DiaChi){
        $connection=new mysqli('localhost', 'root', 'root', 'dulieu');
        if($connection->connect_error){
            die("Connection failed ".$connection->connect_error);
        }
        $preparedStatement=$connection->prepare('update nhanvien set Ho ten=?, Idpb=?, Dia chi=?');
        $preparedStatement->bind_param("sis", $HoTen,$Idpb,$DiaChi);
        if($preparedStatement->execute()) header("Location: ../Index.html");
    }
}
<?php
include_once("../Model/M_Sinhvien.php");
include_once("../Model/M_Khoa.php");

class C_Sinhvien{
    public function invoke()
    {
        $request=$_GET['request'];
        switch ($request) {
            case "xem_danh_sach_nhan_vien":
                $result=M_Sinhvien::getAllSinhvien();
                if(isset($_GET['KhoaId'])){
                    $result=M_Sinhvien::getAllSinhvienByKhoaId($_GET['KhoaId']);
                }
                $danhsachkhoa=M_Khoa::getAllKhoa();
                include_once ("../View/Xemdanhsachsinhvien.php");
                break;
        }
    }
}
$c_sinhvien=new C_Sinhvien();
$c_sinhvien->invoke();


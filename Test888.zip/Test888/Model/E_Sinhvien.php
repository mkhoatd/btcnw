<?php

class E_Sinhvien
{
    public $MSV;
    public $HoTen;
    public $GioiTinh;
    public $KhoaId;
    public $TenKhoa;

    public function __construct($MSV,$HoTen,$GioiTinh,$KhoaId,$TenKhoa)
    {
        $this->$MSV=$MSV;
        $this->HoTen=$HoTen;
        $this->$GioiTinh=$GioiTinh;
        $this->$KhoaId=$KhoaId;
        $this->$TenKhoa=$TenKhoa;

    }

}
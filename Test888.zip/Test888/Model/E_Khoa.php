<?php

class E_Khoa
{
    public $Id;
    public $TenKhoa;

    public function __construct($Id,$TenKhoa)
    {
        $this->$Id=$Id;
        $this->$TenKhoa=$TenKhoa;
    }

}
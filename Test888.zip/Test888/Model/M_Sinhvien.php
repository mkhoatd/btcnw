<?php
include_once('E_Sinhvien.php');
class M_Sinhvien
{
    public static function getAllSinhvien(){
        $connection=new mysqli("localhost","root","root","Test888");
        if($connection->connect_error){
            die("Connection failed ".$connection->connect_error);
        }
        $sql="SELECT * FROM Sinhvien inner join Khoa on Sinhvien.KhoaId=Khoa.Id";
        $result=$connection->query($sql);
        $returnValue=array();
        while($row=$result->fetch_assoc()){
            $returnValue[$row['MSV']]=new E_Sinhvien($row['MSV'],$row['HoTen'],$row['GioiTinh'],$row['KhoaId'],$row['TenKhoa']);
        }
        $connection->close();
        return $returnValue;
    }
    public static function getAllSinhvienByKhoaId($KhoaId){
        $connection=new mysqli("localhost","root","root","Test888");
        if($connection->connect_error){
            die("Connection failed ".$connection->connect_error);
        }
        $sql="SELECT * FROM Sinhvien inner join Khoa on Sinhvien.KhoaId=Khoa.Id where KhoaId=".$KhoaId;
        $result=$connection->query($sql);
        $returnValue=array();
        while($row=$result->fetch_assoc()){
            $returnValue[$row['MSV']]=new E_Sinhvien($row['MSV'],$row['HoTen'],$row['GioiTinh'],$row['KhoaId'],$row['TenKhoa']);
        }
        $result->free();
        $connection->close();
        return $returnValue;
    }
    public static function getAllSinhvienByTenKhoa($TenKhoa){
        $connection=new mysqli("localhost","root","root","Test888");
        if($connection->connect_error){
            die("Connection failed ".$connection->connect_error);
        }
        $sql="SELECT * FROM Sinhvien inner join Khoa on Sinhvien.KhoaId=Khoa.Id where Khoa.TenKhoa=".$TenKhoa;
        $result=$connection->query($sql);
        $returnValue=array();
        while($row=$result->fetch_assoc()){
            $returnValue[$row['MSV']]=new E_Sinhvien($row['MSV'],$row['HoTen'],$row['GioiTinh'],$row['KhoaId'],$row['TenKhoa']);
        }
        $connection->close();
        return $returnValue;
    }
    public static function addSinhvien(){
        $connection=new mysqli("localhost","root","root","Test888");
        if($connection->connect_error){
            die("Connection failed ".$connection->connect_error);
        }
        $sql="INSERT INTO Sinhvien(MSV,HoTen,GioiTinh,KhoaId) VALUES('".$_POST['MSV']."','".$_POST['HoTen']."','".$_POST['GioiTinh']."','".$_POST['KhoaId']."')";
        $result=$connection->query($sql);
        $connection->close();
        return $result;
    }
    public static function deleteSinhvien(){
        $connection=new mysqli("localhost","root","root","Test888");
        if($connection->connect_error){
            die("Connection failed ".$connection->connect_error);
        }
        $sql="DELETE FROM Sinhvien WHERE MSV='".$_POST['MSV']."'";
        $result=$connection->query($sql);
        $connection->close();
        return $result;
    }
    public static function editSinhvien(){
        $connection=new mysqli("localhost","root","root","Test888");
        if($connection->connect_error){
            die("Connection failed ".$connection->connect_error);
        }
        $sql="UPDATE Sinhvien SET HoTen='".$_POST['HoTen']."',GioiTinh='".$_POST['GioiTinh']."',KhoaId='".$_POST['KhoaId']."' WHERE MSV='".$_POST['MSV']."'";
        $result=$connection->query($sql);
        $connection->close();
        return $result;
    }
}


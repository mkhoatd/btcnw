<?php
include_once('E_Khoa.php');
class M_Khoa{
    public static function getAllKhoa(){
        $connection=new mysqli("localhost","root","root","Test888");
        if($connection->connect_error){
            die("Connection failed ".$connection->connect_error);
        }
        $sql="SELECT * FROM Khoa";
        $result=$connection->query($sql);
        $returnValue=array();
        while($row=$result->fetch_assoc()){
            $returnValue[$row['Id']]=new E_Khoa($row['Id'],$row['TenKhoa']);
        }
        $connection->close();
        return $returnValue;
    }
    public static function getKhoaId($TenKhoa){
        $connection=new mysqli("localhost","root","root","Test888");
        if($connection->connect_error){
            die("Connection failed ".$connection->connect_error);
        }
        $sql="SELECT * FROM Khoa WHERE TenKhoa='".$TenKhoa."'";
        $result=$connection->query($sql);
        $row=$result->fetch_assoc();
        $returnValue=$row['Id'];
        $result->free();
        $connection->close();
        return $returnValue;
    }
}
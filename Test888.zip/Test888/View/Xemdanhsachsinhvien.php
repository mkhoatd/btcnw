<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form>
        <select name="KhoaId" action="../Controller/C_Sinhvien" method="get">
            <?php
            foreach($danhsachkhoa as $khoa){
                echo "<option value='".$khoa['KhoaId']."'>".$khoa['TenKhoa']."</option>";
            }
            ?>
        </select>
    </form>
    <br/>
    <table>
        <tr>
            <th>MSV</th>
            <th>Ho ten</th>
            <th>Gioi tinh</th>
            <th>Khoa</th>
            <th></th>
        </tr>
        <?php
        foreach($result as $value)
        {
            echo "<tr>";
            echo "<td>".$value->MSV."</td>";
            echo "<td>$value->HoTen</td>";
            if($value->GioiTinh==1)
            {
                echo "<td>Nam</td>";
            }
            else
            {
                echo "<td>Nu</td>";
            }
            echo "<td>$value->TenKhoa</td>";
            echo "<td></td>";
            echo "<tr>";
        }
        ?>
    </table>
</body>
</html>